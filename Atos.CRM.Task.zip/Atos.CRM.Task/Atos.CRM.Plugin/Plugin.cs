﻿using Atos.CRM.Plugins;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.ServiceModel.Description;
using System.Text;
using System.Threading.Tasks;

namespace Atos.CRM.Plugin
{
    public class Plugin : IPlugin

    {
        public void Execute(IServiceProvider serviceProvider)
        {

            var context = serviceProvider.GetService(typeof(IPluginExecutionContext)) as IPluginExecutionContext;

            //if (context.Stage != 20)
            //  throw new InvalidPluginExecutionException("Musi być uruchomione jako pre-operaion stage 20");


            var tracingService = serviceProvider.GetService(typeof(ITracingService)) as ITracingService;

            tracingService.Trace("SIEMANOOO PLUGIN");

            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            Entity target = (Entity)context.InputParameters["Target"];

            tracingService.Trace("Debug logic = " + context.PreEntityImages.Count);


            Entity preImage = null;

            if (context.MessageName == "Update") //&& context.PreEntityImages.Contains("contact")) 
            {
                preImage = context.PreEntityImages["contact"];
            }
            tracingService.Trace("Debug logic1");


            Entity contact = GetFullEntityWithLatestValues(preImage, target);
            tracingService.Trace("Debug logic2");
            //tracingService.Trace("Debug logic =" + contact.Attributes["jobtitle"]);

            Logic logic = new Logic(contact, null, service);
            tracingService.Trace("Debug logic3");

            int completion = logic.SetValueToCompletion(contact, 0);
            tracingService.Trace("Debug logic4");
            string color = logic.SetValueToColor(contact, "",completion);
            tracingService.Trace("Debug logic5");
            target["new_completion"] = completion;
            tracingService.Trace("Debug logic6");
            //organizationService.Update(contact);

            target["new_color"] = color;
            tracingService.Trace("Debug logic7");
            //organizationService.Update(contact);


        }

        public static void AddOrUpdateAttribute(Entity entity, string attributeKey, object attributeValue)
        {
            attributeKey = attributeKey.ToLower();
            if (entity.Attributes.Contains(attributeKey))
            {
                entity.Attributes[attributeKey] = attributeValue;
            }
            else
            {
                entity.Attributes.Add(new KeyValuePair<string, object>(attributeKey, attributeValue));
            }
        }

        public static Entity GetFullEntityWithLatestValues(Entity preImage, Entity target)
        {
            Entity resultEntity = new Entity(target.LogicalName, target.Id);
            if (preImage == null)
            {
                foreach (var attr in target.Attributes)
                {
                    AddOrUpdateAttribute(resultEntity, attr.Key, attr.Value);
                }
                return resultEntity;
            }
            foreach (var attr in preImage.Attributes)
            {
                AddOrUpdateAttribute(resultEntity, attr.Key, attr.Value);
            }
            foreach (var attr in target.Attributes)
            {
                AddOrUpdateAttribute(resultEntity, attr.Key, attr.Value);
            }
            return resultEntity;
        }


        private static IOrganizationService CreateOrganizationService()
        {
            IOrganizationService organizationService = null;

            try
            {
                ClientCredentials clientCredentials = new ClientCredentials();
                clientCredentials.UserName.UserName = "atoscrmprojekt@atosprojekt.onmicrosoft.com";
                clientCredentials.UserName.Password = "Atosprojekt1";

                // For Dynamics 365 Customer Engagement V9.X, set Security Protocol as TLS12
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                // Get the URL from CRM, Navigate to Settings -> Customizations -> Developer Resources
                // Copy and Paste Organization Service Endpoint Address URL
                organizationService = (IOrganizationService)new OrganizationServiceProxy(new Uri("https://atosprojekt.api.crm4.dynamics.com/XRMServices/2011/Organization.svc"),
                 null, clientCredentials, null);

                if (organizationService != null)
                {
                    Guid userid = ((WhoAmIResponse)organizationService.Execute(new WhoAmIRequest())).UserId;

                    if (userid != Guid.Empty)
                    {
                        Console.WriteLine("Connection Established Successfully...");
                    }
                }
                else
                {
                    Console.WriteLine("Failed to Established Connection!!!");

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception caught - " + ex.Message);
            }

            return organizationService;
        }
    }

    //AccountCreditLimitBL creditLimitBL = new AccountCreditLimitBL(tracingService, service);
    //creditLimitBL.SetDefaultLimit(target);

}
