﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Atos.CRM.Plugins
{
    public class Logic
    {

        private Entity _target;
        private ITracingService _tracingService;
        private IOrganizationService _service;


        public Logic(Entity target, ITracingService tracingService, IOrganizationService service)
        {
            this._target = target;
            this._tracingService = tracingService;
            this._service = service;
        }


        //WEŹ DANE Z ENCJI Config1
        public List<Config1> GetValuesFromConfig1(Entity entity)
        {
            List<Config1> list = new List<Config1>();
            QueryExpression query = new QueryExpression();
            query.EntityName = "new_config1";
            // query.ColumnSet.AddColumn("name");
            query.ColumnSet.AddColumn("new_column");
            query.ColumnSet.AddColumn("new_percentage");
            query.Criteria.AddCondition("new_entity", ConditionOperator.Equal, entity.LogicalName);
            EntityCollection collection = _service.RetrieveMultiple(query);
            foreach (var item in collection.Entities)
            {
                Config1 contact = new Config1();
                //  contact.name = (item.Attributes["new_name"].ToString());
                contact.column = (item.Attributes["new_column"].ToString());
                contact.percentage = Convert.ToInt32(item.Attributes["new_percentage"]);
                list.Add(contact);
            }
            return list;
        }

        //WEŹ DANE Z ENCJI Config2
        public List<Config2> GetValuesFromConfig2(Entity entity)
        {
            List<Config2> list2 = new List<Config2>();
            QueryExpression query = new QueryExpression();
            query.EntityName = "new_config2";
            // query.ColumnSet.AddColumn("name");
            query.ColumnSet.AddColumn("new_groupname");
            query.ColumnSet.AddColumn("new_entityconfig");
            query.ColumnSet.AddColumn("new_percentage");
            query.ColumnSet.AddColumn("new_color");
            query.Criteria.AddCondition("new_entityconfig", ConditionOperator.Equal, entity.LogicalName);
            query.AddOrder("new_percentage", OrderType.Ascending);
            EntityCollection collection = _service.RetrieveMultiple(query);
            foreach (var item in collection.Entities)
            {
                Config2 contact = new Config2();
                //  contact.name = (item.Attributes["new_name"].ToString());
                contact.groupname = (item.Attributes["new_groupname"].ToString());
                contact.entityconfig = (item.Attributes["new_entityconfig"].ToString());
                contact.percentage = Convert.ToInt32(item.Attributes["new_percentage"]);
                contact.color = (item.Attributes["new_color"].ToString());
                list2.Add(contact);
            }
            return list2;
        }

        public int SetValueToCompletion(Entity entity, int completion)
        {
            List<Config1> list1 = GetValuesFromConfig1(entity);
            //ColumnSet columnSet = new ColumnSet();
            //foreach (var item in list1)
            //{
            //    columnSet.AddColumn(item.column);
            //}
            //Entity record = _service.Retrieve(_target.LogicalName, _target.Id, columnSet);
            foreach (var configColumn in list1)
            {
                if (entity.Attributes.Contains(configColumn.column))
                {

                    object value = entity.Attributes[configColumn.column];
                    if (value != null && value.ToString()!="")
                    {
                        completion += configColumn.percentage;
                    }
                }
            }
            return completion;


        }

        public string SetValueToColor(Entity entity, string defaultColor, int currentCompletion)
        {
            List<Config2> list2 = GetValuesFromConfig2(entity);
            //ColumnSet columnSet = new ColumnSet();
            //columnSet.AddColumn("new_completion");
            //Entity record = _service.Retrieve(_target.LogicalName, _target.Id, columnSet);
          //  int check = Convert.ToInt32(entity.Attributes["new_completion"]);
            foreach (var item in list2)
            {
                int check2 = item.percentage;
                if (check2 >= currentCompletion)
                {
                    defaultColor = item.color;
                    break;
                }
                
            }
            return defaultColor;
        }
        public static List<Entity> GetRecords(string entityname, IOrganizationService service)
        {

            List<Entity> contacts = new List<Entity>();
            QueryExpression query = new QueryExpression();
            query.EntityName = entityname;
            query.ColumnSet = new ColumnSet(true);
            EntityCollection collection = service.RetrieveMultiple(query);

            foreach (var item in collection.Entities)
            {
                contacts.Add(item);
            }

            return contacts;
        }

        public void changeValues(Entity entity)
        {
            int completion = 0;
            string check = "";
            int completion2 = SetValueToCompletion(entity, completion);
            string check2 = SetValueToColor(entity, check,completion2);

        }
        public void CheckIfEmptyField(Entity target, int sum)
        {
            if (_tracingService != null)
            {
                _tracingService.Trace("Run CheckIfEmptyField");
            }
            if (target.Contains("jobtitle"))
            {
                target["new_completion"] = sum + 20;
            }
            if (target.Contains("mobilephone"))
            {
                target["new_completion"] = sum + 20;
            }
            if (target.Contains("emailaddress1"))
            {
                target["new_completion"] = sum + 20;
            }
            if (target.Contains("fax"))
            {
                target["new_completion"] = sum + 20;
            }


          
      
        }
    }
}
