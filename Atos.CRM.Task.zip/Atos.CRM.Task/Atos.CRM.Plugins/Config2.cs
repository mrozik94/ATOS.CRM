﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Atos.CRM.Plugins
{
    public class Config2
    {

        public int id;
        public string groupname;
        public string entityconfig;
        public int percentage;
        public string color;
    }
}
