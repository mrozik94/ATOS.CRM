﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Atos.CRM.Plugins
{
    public class Config1
    {
        public int id;
        public string name;
        public string column;
        public int percentage;


    }
}
