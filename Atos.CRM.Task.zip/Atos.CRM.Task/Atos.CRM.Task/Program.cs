﻿using Atos.CRM.Plugins;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.ServiceModel.Description;
using System.Text;
using System.Threading.Tasks;

namespace Atos.CRM.Task
{
    class Program
    {
        static void Main(string[] args)
        {
            IOrganizationService organizationService = CreateOrganizationService();
            //Entity contact = organizationService.Retrieve("contact", new Guid("39A4E5B9-88DF-E311-B8E5-6C3BE5A8B200"), new ColumnSet(true));
            List < Entity > list = Logic.GetRecords("contact",organizationService);
            //Entity contact = new Entity("contact",new Guid("39A4E5B9-88DF-E311-B8E5-6C3BE5A8B200"));


            // Query ktore wyciaga wszystkie kontakty i tylko kolumny z konfiguracji + completion i kolor

            foreach (Entity contact in list)
            {
                Logic logic = new Logic(contact, null, organizationService);



                int completion = logic.SetValueToCompletion(contact, 0);
                string color = logic.SetValueToColor(contact, "", completion);

                Entity contactForUpdate = new Entity(contact.LogicalName, contact.Id);
                if ((contact.Attributes.Contains("new_completion") && int.Parse(contact["new_completion"].ToString()) != completion) ||
                    (!contact.Attributes.Contains("new_completion")))
                {

                    contactForUpdate["new_completion"] = completion;
                }
                if ((contact.Attributes.Contains("new_color") && contact["new_color"].ToString() != color) ||
                   (!contact.Attributes.Contains("new_color")))
                {
                    contactForUpdate["new_color"] = color;

                }

                if (contactForUpdate.Attributes.Count > 0)
                {
                    organizationService.Update(contactForUpdate);
                }
            }
        }

        private static IOrganizationService CreateOrganizationService()
        {
            IOrganizationService organizationService = null;

            try
            {
                ClientCredentials clientCredentials = new ClientCredentials();
                clientCredentials.UserName.UserName = "atoscrmprojekt@atosprojekt.onmicrosoft.com";
                clientCredentials.UserName.Password = "Atosprojekt1";

                // For Dynamics 365 Customer Engagement V9.X, set Security Protocol as TLS12
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                // Get the URL from CRM, Navigate to Settings -> Customizations -> Developer Resources
                // Copy and Paste Organization Service Endpoint Address URL
                organizationService = (IOrganizationService)new OrganizationServiceProxy(new Uri("https://atosprojekt.api.crm4.dynamics.com/XRMServices/2011/Organization.svc"),
                 null, clientCredentials, null);

                if (organizationService != null)
                {
                    Guid userid = ((WhoAmIResponse)organizationService.Execute(new WhoAmIRequest())).UserId;

                    if (userid != Guid.Empty)
                    {
                        Console.WriteLine("Connection Established Successfully...");
                    }
                }
                else
                {
                    Console.WriteLine("Failed to Established Connection!!!");

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception caught - " + ex.Message);
            }

            return organizationService;
        }
    }
}
