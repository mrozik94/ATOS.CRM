﻿//function GetValues() {
//    var completion = 0;
//    var color = "";
//    if (Xrm.Page.getAttribute("new_completion").getValue() != null){
//        completion = Xrm.Page.getAttribute("new_completion").getValue();
//        color = Xrm.Page.getAttribute("new_color").getValue();
//        Xrm.Page.getAttribute("new_copy_completion").setValue(completion);
//        Xrm.Page.getAttribute("new_copy_color").setValue(color);

//    }
//}

function CompletionOnChange() {

    //var webResource = Xrm.Page.ui.controls.get("WebResource_test");
    //var webSource = webResource.getSrc();
    //webResource.setSrc(null);
    //webResource.setSrc(webSource);
    parent.window.document.getElementById("WebResource_test").contentWindow.Reload();
}

function ColorOnChange() {
    parent.window.document.getElementById("WebResource_test").contentWindow.SetFrameColor();

}
function OnLoad() {
    Xrm.Page.getAttribute("new_completion").addOnChange(CompletionOnChange);
    Xrm.Page.getAttribute("new_color").addOnChange(ColorOnChange);
    parent.window.document.addEventListener('readystatechange',  event  =>  {

            if  (event.target.readyState  ===  "interactive")  {      //same as:  document.addEventListener("DOMContentLoaded"
                    alert("All HTML DOM elements are accessible");
            }

            if  (event.target.readyState  ===  "complete")  {
                    alert("Now external resources are loaded too, like css,src etc... ");
            }

    }); 
}